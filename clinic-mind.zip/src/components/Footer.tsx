"use client";

import { Link } from "@/i18n/navigation";
import { useTranslations } from "next-intl";

export default function Footer() {
  const t = useTranslations("footer");
  const tNav = useTranslations("nav");

  const navLinks = [
    { href: "/" as const, label: tNav("home") },
    { href: "/about" as const, label: tNav("about") },
    { href: "/servicios" as const, label: tNav("services") },
    { href: "/blog" as const, label: tNav("blog") },
    { href: "/contacto" as const, label: tNav("contact") },
  ];

  return (
    <footer className="bg-warm-100 border-t border-warm-200 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-sage-700 font-semibold text-lg mb-3">Lic. Micaela Vulcano</h3>
            <p className="text-warm-600 text-sm leading-relaxed">{t("brand")}</p>
          </div>

          <div>
            <h4 className="text-warm-800 font-medium mb-3 text-sm uppercase tracking-wide">{t("navigation")}</h4>
            <ul className="space-y-2">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-warm-600 hover:text-sage-600 text-sm transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-warm-800 font-medium mb-3 text-sm uppercase tracking-wide">{t("contact")}</h4>
            <ul className="space-y-2 text-sm text-warm-600">
              <li>
                <a href="https://wa.me/5491122554035" target="_blank" rel="noopener noreferrer" className="hover:text-sage-600 transition-colors flex items-center gap-2">
                  <svg className="w-4 h-4 text-sage-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                  {t("whatsapp")}
                </a>
              </li>
              <li className="text-warm-500 text-xs mt-3">{t("schedule")}</li>
              <li className="text-warm-500 text-xs">{t("modality")}</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-warm-200 mt-10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-warm-500 text-xs">
            © {new Date().getFullYear()} Lic. Micaela Vulcano. {t("rights")}
          </p>
          <p className="text-warm-400 text-xs">{t("license")}</p>
        </div>
      </div>
    </footer>
  );
}
